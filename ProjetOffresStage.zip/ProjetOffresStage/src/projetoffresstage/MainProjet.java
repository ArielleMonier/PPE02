package projetoffresstage;
import java.util.ArrayList;
/**
 *
 * @author jeremy
 */
public class MainProjet {

    /**
     * @param args the command line arguments
     */
    private ArrayList<String>lesOffres;
    private ArrayList<Entreprise>lesEntreprises;
    public static void main(String[] args) {
        
    }
    
}
